## Scripts used

GetSSHFromPrivateStorage.py   
  
WriteSSHToPrivateStorage.py  
deploy-back.sh  
deploy-front.sh	missing  
deploy-prestashop.yml  
deploy.sh	  
ansible-csync2-lsyncd   
ansible-init-raid  
hosts.example  
install_roles.yml  
php.ini  
