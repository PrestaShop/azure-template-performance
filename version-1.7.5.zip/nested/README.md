## Back and Front Tremplates

Front for apache/php-fpm VMs  
Back for Master/Slave MySQL  
